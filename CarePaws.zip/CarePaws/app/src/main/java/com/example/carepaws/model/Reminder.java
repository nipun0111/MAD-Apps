package com.example.carepaws.model;

public class Reminder {
    private String id;
    private String title;
    private String dateTime; // stored as "Today, 09:00 AM" or "Tuesday, Oct 24 • 11:00 AM"
    private long triggerTimestamp; // actual epoch ms for AlarmManager
    private boolean notifyEnabled;
    private String type; // Medicine, Walk, Vet, Grooming

    public Reminder() {}

    public Reminder(String title, String dateTime, long triggerTimestamp, boolean notifyEnabled, String type) {
        this.title = title;
        this.dateTime = dateTime;
        this.triggerTimestamp = triggerTimestamp;
        this.notifyEnabled = notifyEnabled;
        this.type = type;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }

    public long getTriggerTimestamp() { return triggerTimestamp; }
    public void setTriggerTimestamp(long triggerTimestamp) { this.triggerTimestamp = triggerTimestamp; }

    public boolean isNotifyEnabled() { return notifyEnabled; }
    public void setNotifyEnabled(boolean notifyEnabled) { this.notifyEnabled = notifyEnabled; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
