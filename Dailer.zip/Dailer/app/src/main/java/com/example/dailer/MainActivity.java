package com.example.dailer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etDialer;
    HistoryDatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etDialer = findViewById(R.id.etDialer);
        db = new HistoryDatabaseHelper(this);

        // Receive Intent Core Logic
        if (getIntent() != null && getIntent().hasExtra("phone")) {
            String number = getIntent().getStringExtra("phone");
            if (number != null) {
                etDialer.setText(number);
            }
        }

        // Call button click listener update karein
        findViewById(R.id.btnCall).setOnClickListener(v -> {
            String num = etDialer.getText().toString();
            if (!num.isEmpty()) {
                makeDirectCall(num);
            } else {
                Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            }
        });
        // End of onCreate

        // Yeh naya method add karein

        ImageButton btnBackspace = findViewById(R.id.btnBackspace);

        // 1. Single click - Ek digit delete karne ke liye
        btnBackspace.setOnClickListener(v -> {
            String currentText = etDialer.getText().toString();
            if (currentText.length() > 0) {
                // Last character ko hata kar naya text set karein
                String newText = currentText.substring(0, currentText.length() - 1);
                etDialer.setText(newText);
            }
        });

        // 2. Long press (Hold) - Poora number ek sath clear karne ke liye (Bonus Feature!)
        btnBackspace.setOnLongClickListener(v -> {
            etDialer.setText("");
            return true; // Return true matlab long press event yahin consume ho gaya
        });
    }
//        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, CallHistoryActivity.class)));
//    }
//
//    // Handle Dial Pad Clicks
    public void onDialPadClick(View view) {
        Button b = (Button) view;
        etDialer.append(b.getText().toString());
    }

    private void makeDirectCall (String phoneNumber){
        // Permission check karein
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // Agar permission nahi hai, toh user se request karein
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
        } else {
            // Agar permission hai, toh directly call lagayein aur history save karein
            db.insertHistory(phoneNumber);
            Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phoneNumber));
            startActivity(callIntent);
        }
    }
}