package com.example.studentapp;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText etName, etRoll, etMarks;
    Button btnAdd, btnView;

    StudentDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etRoll = findViewById(R.id.etRoll);
        etMarks = findViewById(R.id.etMarks);
        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);

        dao = new StudentDAO(this);

        // Add Button
        btnAdd.setOnClickListener(v -> {
            boolean inserted = dao.insertData(
                    etName.getText().toString(),
                    etRoll.getText().toString(),
                    etMarks.getText().toString()
            );

            if (inserted) {
                Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
            }
        });

        // View Button
        btnView.setOnClickListener(v -> {
            Cursor res = dao.getAllData();

            if (res.getCount() == 0) {
                showMessage("Error", "No Data Found");
                return;
            }

            StringBuilder buffer = new StringBuilder();

            while (res.moveToNext()) {
                buffer.append("ID: ").append(res.getString(0)).append("\n");
                buffer.append("Name: ").append(res.getString(1)).append("\n");
                buffer.append("Roll: ").append(res.getString(2)).append("\n");
                buffer.append("Marks: ").append(res.getString(3)).append("\n\n");
            }

            showMessage("Student Data", buffer.toString());
        });
    }

    private void showMessage(String title, String message) {
        new android.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setCancelable(true)
                .show();
    }
}