package com.example.carepaws.utils;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;

import com.example.carepaws.R;

public class AnimationUtils {

    public static void showSuccessPopup(ViewGroup root) {
        if (root == null) return;
        
        View popup = LayoutInflater.from(root.getContext()).inflate(R.layout.layout_success_popup, root, false);
        root.addView(popup);
        
        // Initial state
        popup.setAlpha(0f);
        popup.setScaleX(0.7f);
        popup.setScaleY(0.7f);
        
        // Appear animation
        popup.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(400)
                .setInterpolator(new AnticipateOvershootInterpolator())
                .withEndAction(() -> {
                    // Wait and disappear
                    popup.postDelayed(() -> {
                        popup.animate()
                                .alpha(0f)
                                .scaleX(0.8f)
                                .scaleY(0.8f)
                                .setDuration(300)
                                .setInterpolator(new AccelerateInterpolator())
                                .withEndAction(() -> root.removeView(popup))
                                .start();
                    }, 1200);
                })
                .start();
    }
}

