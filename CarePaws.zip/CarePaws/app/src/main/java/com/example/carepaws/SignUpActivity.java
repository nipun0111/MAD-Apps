package com.example.carepaws;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.carepaws.utils.AnimationUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        Button btnCreate = findViewById(R.id.btn_create_account);
        TextView tvSignIn = findViewById(R.id.tv_sign_in);

        btnCreate.setOnClickListener(v -> {
            btnCreate.setEnabled(false);
            btnCreate.setText("Creating...");
            createAccount();
        });

        tvSignIn.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void createAccount() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            etName.setError("Name is required");
            findViewById(R.id.btn_create_account).setEnabled(true);
            ((Button) findViewById(R.id.btn_create_account)).setText("Create Account");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email is required");
            findViewById(R.id.btn_create_account).setEnabled(true);
            ((Button) findViewById(R.id.btn_create_account)).setText("Create Account");
            return;
        }
        if (password.length() < 8) {
            etPassword.setError("Password must be at least 8 characters");
            findViewById(R.id.btn_create_account).setEnabled(true);
            ((Button) findViewById(R.id.btn_create_account)).setText("Create Account");
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful() && mAuth.getCurrentUser() != null) {
                        // Update display name
                        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                .setDisplayName(name).build();
                        mAuth.getCurrentUser().updateProfile(profileUpdates);

                        // Save user info to Firestore
                        String uid = mAuth.getCurrentUser().getUid();
                        Map<String, Object> user = new HashMap<>();
                        user.put("name", name);
                        user.put("email", email);
                        db.collection("users").document(uid).set(user);

                        AnimationUtils.showSuccessPopup((ViewGroup) findViewById(android.R.id.content));

                        // Go to pet setup
                        startActivity(new Intent(SignUpActivity.this, PetSetupActivity.class));
                        finish();
                    } else {
                        findViewById(R.id.btn_create_account).setEnabled(true);
                        ((Button) findViewById(R.id.btn_create_account)).setText("Create Account");
                        String error = task.getException() != null ? task.getException().getMessage() : "Sign up failed";
                        Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                    }
                });
    }
}
