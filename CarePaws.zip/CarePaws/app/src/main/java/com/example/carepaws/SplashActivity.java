package com.example.carepaws;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        CardView cardLogo = findViewById(R.id.card_splash_logo);
        TextView tvText = findViewById(R.id.tv_splash_text);

        // Pre-animation state
        cardLogo.setTranslationY(100f);
        cardLogo.setScaleX(0.8f);
        cardLogo.setScaleY(0.8f);
        
        tvText.setTranslationY(50f);

        // Animate Logo
        cardLogo.animate()
                .translationY(0)
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(1000)
                .setInterpolator(new AnticipateOvershootInterpolator())
                .start();

        // Animate Text with slight delay
        tvText.animate()
                .translationY(0)
                .alpha(1f)
                .setDuration(800)
                .setStartDelay(300)
                .setInterpolator(new OvershootInterpolator())
                .start();

        // Navigate after delay
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            Intent intent;
            if (currentUser != null) {
                intent = new Intent(SplashActivity.this, MainActivity.class);
            } else {
                intent = new Intent(SplashActivity.this, WelcomeActivity.class);
            }
            startActivity(intent);
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 2500);
    }
}
