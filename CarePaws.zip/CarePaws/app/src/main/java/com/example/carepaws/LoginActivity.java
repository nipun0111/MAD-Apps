package com.example.carepaws;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.carepaws.utils.AnimationUtils;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        Button btnSignIn = findViewById(R.id.btn_sign_in);
        TextView tvSignUp = findViewById(R.id.tv_sign_up);

        btnSignIn.setOnClickListener(v -> {
            btnSignIn.setEnabled(false);
            btnSignIn.setText("Checking...");
            signIn();
        });

        tvSignUp.setOnClickListener(v -> {
            startActivity(new Intent(this, SignUpActivity.class));
            finish();
        });
    }

    private void signIn() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email is required");
            findViewById(R.id.btn_sign_in).setEnabled(true);
            ((Button) findViewById(R.id.btn_sign_in)).setText("Sign In");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password is required");
            findViewById(R.id.btn_sign_in).setEnabled(true);
            ((Button) findViewById(R.id.btn_sign_in)).setText("Sign In");
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        AnimationUtils.showSuccessPopup((ViewGroup) findViewById(android.R.id.content));
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    } else {
                        findViewById(R.id.btn_sign_in).setEnabled(true);
                        ((Button) findViewById(R.id.btn_sign_in)).setText("Sign In");
                        String error = task.getException() != null ? task.getException().getMessage() : "Sign in failed";
                        Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                    }
                });
    }
}
