package com.example.radio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup departmentRadioGroup;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        departmentRadioGroup = findViewById(R.id.departmentRadioGroup);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Submit Button Click Listener
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the ID of the selected RadioButton
                int selectedId = departmentRadioGroup.getCheckedRadioButtonId();

                // Check if any option is selected
                if (selectedId != -1) {
                    // Find the selected RadioButton view
                    RadioButton selectedRadioButton = findViewById(selectedId);
                    String selectedText = selectedRadioButton.getText().toString();

                    // Modern apps show selection immediately, but we are using Submit button here
                    Toast.makeText(MainActivity.this, "Final Selection: " + selectedText, Toast.LENGTH_SHORT).show();
                } else {
                    // This case won't be hit because we set android:checked="true" for "Other" in XML
                    Toast.makeText(MainActivity.this, "Please select your department", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}