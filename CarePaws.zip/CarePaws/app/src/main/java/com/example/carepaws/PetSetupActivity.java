package com.example.carepaws;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.carepaws.utils.AnimationUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class PetSetupActivity extends AppCompatActivity {

    private EditText etPetName, etBreed, etAnimalType, etAge, etWeight, etMedicalIssues;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_setup);

        db = FirebaseFirestore.getInstance();

        etPetName = findViewById(R.id.et_pet_name);
        etBreed = findViewById(R.id.et_breed);
        etAnimalType = findViewById(R.id.et_animal_type);
        etAge = findViewById(R.id.et_age);
        etWeight = findViewById(R.id.et_weight);
        etMedicalIssues = findViewById(R.id.et_medical_issues);
        Button btnContinue = findViewById(R.id.btn_continue);
        ImageView btnBack = findViewById(R.id.btn_back);

        btnContinue.setOnClickListener(v -> savePetProfile(btnContinue));
        btnBack.setOnClickListener(v -> finish());

        checkExistingPets(btnBack);
    }

    private void checkExistingPets(ImageView btnBack) {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        db.collection("users").document(uid).collection("pets")
                .limit(1).get().addOnSuccessListener(qs -> {
                    if (!qs.isEmpty()) {
                        btnBack.setVisibility(View.VISIBLE);
                    }
                });
    }

    private void savePetProfile(Button btnContinue) {
        String name = etPetName.getText().toString().trim();
        String breed = etBreed.getText().toString().trim();
        String animalType = etAnimalType.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();
        String medicalIssues = etMedicalIssues.getText().toString().trim();

        // 1. Validation Logic
        if (TextUtils.isEmpty(name)) {
            etPetName.setError("Pet name is required");
            return;
        }
        if (TextUtils.isEmpty(breed)) {
            etBreed.setError("Breed is required");
            return;
        }
        if (TextUtils.isEmpty(animalType)) {
            etAnimalType.setError("Animal type is required");
            return;
        }
        if (TextUtils.isEmpty(ageStr)) {
            etAge.setError("Age is required");
            return;
        }
        if (TextUtils.isEmpty(weightStr)) {
            etWeight.setError("Weight is required");
            return;
        }

        int age, weight;
        try {
            age = Integer.parseInt(ageStr);
            weight = Integer.parseInt(weightStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Age and weight must be numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        // 2. Set UI to Saving state ONLY after validation passes
        btnContinue.setEnabled(false);
        btnContinue.setText("Saving...");

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Map<String, Object> pet = new HashMap<>();
        pet.put("name", name);
        pet.put("breed", breed);
        pet.put("animalType", animalType);
        pet.put("medicalIssues", medicalIssues);
        pet.put("age", age);
        pet.put("weight", weight);
        pet.put("photoUrl", "");

        db.collection("users").document(uid).collection("pets").add(pet)
                .addOnSuccessListener(ref -> {
                    AnimationUtils.showSuccessPopup((ViewGroup) findViewById(android.R.id.content));
                    
                    // Delay navigation so the success popup is visible
                    findViewById(android.R.id.content).postDelayed(() -> {
                        // Final navigation logic
                        db.collection("users").document(uid).collection("pets").limit(2).get()
                                .addOnSuccessListener(qs -> {
                                    if (qs.size() <= 1) {
                                        startActivity(new Intent(PetSetupActivity.this, MainActivity.class));
                                    }
                                    finish();
                                })
                                .addOnFailureListener(e -> finish());
                    }, 800);
                })
                .addOnFailureListener(e -> {
                    btnContinue.setEnabled(true);
                    btnContinue.setText("Continue");
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}
