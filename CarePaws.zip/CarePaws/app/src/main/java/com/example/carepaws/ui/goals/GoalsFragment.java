package com.example.carepaws.ui.goals;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import com.example.carepaws.R;
import com.example.carepaws.utils.AnimationUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class GoalsFragment extends Fragment {

    private FirebaseFirestore db;
    private String uid, petId;
    private int walkDuration = 60; // minutes
    private int foodTarget = 2; // meals
    private int sleepTarget = 14; // hours
    private int walkCount = 0;
    private int foodCount = 0;

    private TextView tvMainTitle, tvSubtitle, tvWalkVal, tvFoodVal, tvSleepVal, tvGrowthDesc, tvProgress;
    private SeekBar sbWalk, sbSleep;
    private ImageView btnMinus, btnPlus;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_goals, container, false);

        db = FirebaseFirestore.getInstance();
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        petId = getContext().getSharedPreferences("CarePaws", 0).getString("currentPetId", "");

        tvMainTitle = root.findViewById(R.id.tv_main_title);
        tvSubtitle = root.findViewById(R.id.tv_subtitle);
        tvWalkVal = root.findViewById(R.id.tv_walk_duration_val);
        tvFoodVal = root.findViewById(R.id.tv_meals_val);
        tvSleepVal = root.findViewById(R.id.tv_sleep_target_val);
        tvGrowthDesc = root.findViewById(R.id.tv_growth_tracker_desc);
        
        sbWalk = root.findViewById(R.id.sb_walk_duration);
        sbSleep = root.findViewById(R.id.sb_sleep_target);
        btnMinus = root.findViewById(R.id.btn_meals_minus);
        btnPlus = root.findViewById(R.id.btn_meals_plus);

        root.findViewById(R.id.btn_back).setOnClickListener(v -> Navigation.findNavController(v).popBackStack());

        sbWalk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                walkDuration = progress;
                tvWalkVal.setText(String.valueOf(walkDuration));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        sbSleep.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sleepTarget = progress;
                tvSleepVal.setText(String.valueOf(sleepTarget));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnMinus.setOnClickListener(v -> {
            if (foodTarget > 0) {
                foodTarget--;
                tvFoodVal.setText(String.valueOf(foodTarget));
            }
        });

        btnPlus.setOnClickListener(v -> {
            foodTarget++;
            tvFoodVal.setText(String.valueOf(foodTarget));
        });

        Button btnSave = root.findViewById(R.id.btn_save_goals);
        btnSave.setOnClickListener(v -> {
            btnSave.setEnabled(false);
            btnSave.setText("Saving...");
            saveGoals(btnSave);
        });

        loadPetData();
        loadCurrentGoals();

        return root;
    }

    private void loadPetData() {
        if (petId.isEmpty()) return;
        db.collection("users").document(uid).collection("pets").document(petId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        String name = doc.getString("name");
                        String breed = doc.getString("breed");
                        Long age = doc.getLong("age");
                        if (name != null) {
                            tvMainTitle.setText("Crafting " + name + "'s\nPerfect Day");
                            tvSubtitle.setText("Tailor the rhythm of " + name + "'s daily needs to ensure he stays vibrant and happy.");
                            tvGrowthDesc.setText("Setting these goals helps " + name + " stay within the optimal vitality range for a " + (age != null ? age : "3") + "-year-old " + (breed != null ? breed : "Pet") + ".");
                        }
                    }
                });
    }

    private void loadCurrentGoals() {
        if (petId.isEmpty()) return;
        db.collection("users").document(uid).collection("pets").document(petId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        Long wd = doc.getLong("walkDuration");
                        Long ft = doc.getLong("foodTarget");
                        Long st = doc.getLong("sleepTarget");
                        if (wd != null) {
                            walkDuration = wd.intValue();
                            sbWalk.setProgress(walkDuration);
                            tvWalkVal.setText(String.valueOf(walkDuration));
                        }
                        if (ft != null) {
                            foodTarget = ft.intValue();
                            tvFoodVal.setText(String.valueOf(foodTarget));
                        }
                        if (st != null) {
                            sleepTarget = st.intValue();
                            sbSleep.setProgress(sleepTarget);
                            tvSleepVal.setText(String.valueOf(sleepTarget));
                        }
                    }
                });
    }

    private void saveGoals(Button btn) {
        if (petId.isEmpty()) return;
        Map<String, Object> updates = new HashMap<>();
        updates.put("walkDuration", walkDuration);
        updates.put("foodTarget", foodTarget);
        updates.put("sleepTarget", sleepTarget);

        db.collection("users").document(uid).collection("pets").document(petId)
                .update(updates)
                .addOnFailureListener(e -> {
                    android.widget.Toast.makeText(getContext(), "Error saving to cloud: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                });

        // Optimistic UI update
        btn.setText("Saved ✓");
        btn.postDelayed(() -> {
            btn.setEnabled(true);
            btn.setText("Set New Goals");
        }, 1000);
    }
}
