package com.example.carepaws.ui.reminders;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.carepaws.R;
import com.example.carepaws.ReminderReceiver;
import com.example.carepaws.model.Reminder;
import com.example.carepaws.utils.AnimationUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RemindersFragment extends Fragment {

    private FirebaseFirestore db;
    private String uid;
    private List<Reminder> todayList = new ArrayList<>();
    private List<Reminder> upcomingList = new ArrayList<>();
    private ReminderAdapter todayAdapter, upcomingAdapter;
    private TextView tvPendingCount;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_reminders, container, false);

        db = FirebaseFirestore.getInstance();
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        tvPendingCount = root.findViewById(R.id.tv_pending_count);

        RecyclerView rvToday = root.findViewById(R.id.rv_today_reminders);
        RecyclerView rvUpcoming = root.findViewById(R.id.rv_upcoming_reminders);

        rvToday.setLayoutManager(new LinearLayoutManager(getContext()));
        rvUpcoming.setLayoutManager(new LinearLayoutManager(getContext()));

        ReminderAdapter.OnReminderDeleteListener deleteListener = reminder -> {
            new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Delete Reminder")
                .setMessage("Are you sure you want to delete this reminder?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.collection("users").document(uid).collection("reminders").document(reminder.getId()).delete();
                    cancelAlarm(reminder);
                })
                .setNegativeButton("Cancel", null)
                .show();
        };

        todayAdapter = new ReminderAdapter(todayList, this::onToggleReminder, deleteListener);
        upcomingAdapter = new ReminderAdapter(upcomingList, this::onToggleReminder, deleteListener);

        rvToday.setAdapter(todayAdapter);
        rvUpcoming.setAdapter(upcomingAdapter);

        FloatingActionButton fab = root.findViewById(R.id.fab_add_reminder);
        fab.setOnClickListener(v -> showAddReminderDialog());

        loadReminders();

        return root;
    }

    private void loadReminders() {
        db.collection("users").document(uid).collection("reminders")
                .orderBy("triggerTimestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null) return;

                    todayList.clear();
                    upcomingList.clear();

                    Calendar todayStart = Calendar.getInstance();
                    todayStart.set(Calendar.HOUR_OF_DAY, 0);
                    todayStart.set(Calendar.MINUTE, 0);

                    Calendar todayEnd = Calendar.getInstance();
                    todayEnd.set(Calendar.HOUR_OF_DAY, 23);
                    todayEnd.set(Calendar.MINUTE, 59);

                    for (DocumentSnapshot doc : value.getDocuments()) {
                        Reminder r = doc.toObject(Reminder.class);
                        if (r != null) {
                            r.setId(doc.getId());
                            long ts = r.getTriggerTimestamp();
                            if (ts >= todayStart.getTimeInMillis() && ts <= todayEnd.getTimeInMillis()) {
                                todayList.add(r);
                            } else if (ts > todayEnd.getTimeInMillis()) {
                                upcomingList.add(r);
                            }
                        }
                    }

                    tvPendingCount.setText(todayList.size() + " Pending");
                    todayAdapter.notifyDataSetChanged();
                    upcomingAdapter.notifyDataSetChanged();
                });
    }

    private void onToggleReminder(Reminder reminder, boolean enabled) {
        if (getContext() == null || reminder.getId() == null) return;

        db.collection("users").document(uid).collection("reminders")
                .document(reminder.getId())
                .update("notifyEnabled", enabled);

        if (enabled) {
            scheduleAlarm(reminder);
        } else {
            cancelAlarm(reminder);
        }

        if (getView() instanceof ViewGroup) {
            AnimationUtils.showSuccessPopup((ViewGroup) getView());
        }
    }

    private void showAddReminderDialog() {
        BottomSheetDialog dialog = new BottomSheetDialog(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_reminder, null);
        dialog.setContentView(view);

        EditText etTitle = view.findViewById(R.id.et_reminder_title);
        TextView tvDateTime = view.findViewById(R.id.tv_selected_datetime);
        LinearLayout llPickDateTime = view.findViewById(R.id.ll_pick_datetime);
        Button btnSave = view.findViewById(R.id.btn_save_reminder);

        // Type chips
        TextView chipMedicine = view.findViewById(R.id.chip_medicine);
        TextView chipWalk = view.findViewById(R.id.chip_walk);
        TextView chipVet = view.findViewById(R.id.chip_vet);
        TextView chipGrooming = view.findViewById(R.id.chip_grooming);
        final String[] selectedType = {"Medicine"};
        TextView[] chips = {chipMedicine, chipWalk, chipVet, chipGrooming};
        String[] types = {"Medicine", "Walk", "Vet", "Grooming"};

        for (int i = 0; i < chips.length; i++) {
            final int idx = i;
            chips[i].setOnClickListener(v -> {
                selectedType[0] = types[idx];
                for (int j = 0; j < chips.length; j++) {
                    chips[j].setBackgroundResource(j == idx ? R.drawable.bg_toggle_selected : R.drawable.bg_toggle_unselected);
                    chips[j].setTextColor(j == idx ?
                            getResources().getColor(R.color.white) :
                            getResources().getColor(R.color.text_primary));
                }
            });
        }

        final Calendar selectedCal = Calendar.getInstance();
        llPickDateTime.setOnClickListener(v -> {
            // Date first, then time
            new DatePickerDialog(getContext(), (dp, year, month, day) -> {
                selectedCal.set(Calendar.YEAR, year);
                selectedCal.set(Calendar.MONTH, month);
                selectedCal.set(Calendar.DAY_OF_MONTH, day);

                new TimePickerDialog(getContext(), (tp, hour, minute) -> {
                    selectedCal.set(Calendar.HOUR_OF_DAY, hour);
                    selectedCal.set(Calendar.MINUTE, minute);
                    selectedCal.set(Calendar.SECOND, 0);

                    SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM dd • hh:mm a", Locale.getDefault());
                    tvDateTime.setText(sdf.format(selectedCal.getTime()));
                    tvDateTime.setTextColor(getResources().getColor(R.color.text_primary));
                }, selectedCal.get(Calendar.HOUR_OF_DAY), selectedCal.get(Calendar.MINUTE), false).show();

            }, selectedCal.get(Calendar.YEAR), selectedCal.get(Calendar.MONTH), selectedCal.get(Calendar.DAY_OF_MONTH)).show();
        });

        btnSave.setOnClickListener(v -> {
            btnSave.setEnabled(false);
            btnSave.setText("Setting...");
            String title = etTitle.getText().toString().trim();
            if (title.isEmpty()) {
                etTitle.setError("Title required");
                btnSave.setEnabled(true);
                btnSave.setText("Save Reminder");
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM dd • hh:mm a", Locale.getDefault());
            String dateTimeStr = sdf.format(selectedCal.getTime());

            Map<String, Object> data = new HashMap<>();
            data.put("title", title);
            data.put("dateTime", dateTimeStr);
            data.put("triggerTimestamp", selectedCal.getTimeInMillis());
            data.put("notifyEnabled", true);
            data.put("type", selectedType[0]);

            db.collection("users").document(uid).collection("reminders")
                    .add(data)
                    .addOnSuccessListener(ref -> {
                        // Schedule alarm
                        Reminder r = new Reminder(title, dateTimeStr, selectedCal.getTimeInMillis(), true, selectedType[0]);
                        r.setId(ref.getId());
                        scheduleAlarm(r);
                        if (getActivity() != null) {
                            AnimationUtils.showSuccessPopup((ViewGroup) getActivity().findViewById(android.R.id.content));
                        }
                        dialog.dismiss();
                    })
                    .addOnFailureListener(e -> {
                        btnSave.setEnabled(true);
                        btnSave.setText("Save Reminder");
                        Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
        });

        dialog.show();
    }

    private void scheduleAlarm(Reminder r) {
        Context ctx = getContext();
        if (ctx == null) return;
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        intent.putExtra("title", r.getTitle());
        intent.putExtra("type", r.getType());

        int requestCode = r.getId().hashCode();
        PendingIntent pi = PendingIntent.getBroadcast(ctx, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.getTriggerTimestamp(), pi);
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.getTriggerTimestamp(), pi);
            }
        }
    }

    private void cancelAlarm(Reminder r) {
        Context ctx = getContext();
        if (ctx == null) return;
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        int requestCode = r.getId().hashCode();
        PendingIntent pi = PendingIntent.getBroadcast(ctx, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(pi);
        }
    }
}
