package com.example.carepaws.model;

public class Pet {
    private String id;
    private String name;
    private String breed;
    private String animalType;
    private String medicalIssues;
    private int age;
    private int weight;
    private String photoUrl;

    public Pet() {
        // Default constructor required for calls to DataSnapshot.getValue(Pet.class)
    }

    public Pet(String name, String breed, String animalType, String medicalIssues, int age, int weight, String photoUrl) {
        this.name = name;
        this.breed = breed;
        this.animalType = animalType;
        this.medicalIssues = medicalIssues;
        this.age = age;
        this.weight = weight;
        this.photoUrl = photoUrl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getAnimalType() {
        return animalType;
    }

    public void setAnimalType(String animalType) {
        this.animalType = animalType;
    }

    public String getMedicalIssues() {
        return medicalIssues;
    }

    public void setMedicalIssues(String medicalIssues) {
        this.medicalIssues = medicalIssues;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }
}
