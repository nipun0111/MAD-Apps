package com.example.carepaws.ui.addlog;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import com.example.carepaws.R;
import com.example.carepaws.model.LogEntry;
import com.example.carepaws.utils.AnimationUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AddLogFragment extends Fragment {

    private String selectedType = "Food";
    private String selectedMealType = "Dry Kibble";
    private double portionSize = 1.5;
    private String selectedTime = "08:30 AM";

    private View llDefaultHeader, gridActivityTypes, containerFoodLog, containerSpecializedLog, layoutLogWalk, layoutLogMedicine, layoutLogNotes;
    private TextView tvTitle, tvSubtitle;
    private TextView tvMealDry, tvMealWet, tvMealTreat;
    private String selectedMood = "Happy";
    private ConstraintLayout btnFood, btnWalk, btnMedicine, btnNotes;
    private TextView tvFoodLabel, tvWalkLabel, tvMedLabel, tvNotesLabel;
    private TextView tvPortionValue;
    private EditText etDetails;
    private FirebaseFirestore db;
    private String uid;
    private String petName = "your pet";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_add_log, container, false);

        db = FirebaseFirestore.getInstance();
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        llDefaultHeader = root.findViewById(R.id.ll_default_header);
        gridActivityTypes = root.findViewById(R.id.grid_activity_types);
        tvTitle = root.findViewById(R.id.tv_title);
        tvSubtitle = root.findViewById(R.id.tv_subtitle);
        containerFoodLog = root.findViewById(R.id.container_food_log);
        containerSpecializedLog = root.findViewById(R.id.container_specialized_log);
        layoutLogWalk = root.findViewById(R.id.layout_log_walk);
        layoutLogMedicine = root.findViewById(R.id.layout_log_medicine);
        layoutLogNotes = root.findViewById(R.id.layout_log_notes);

        // Load pet name for subtitle
        db.collection("users").document(uid).collection("pets")
                .limit(1).get().addOnSuccessListener(qs -> {
                    if (!qs.isEmpty()) {
                        petName = qs.getDocuments().get(0).getString("name");
                        if (petName != null) {
                            tvSubtitle.setText(String.format("Let's record %s's latest activity.", petName));
                            updateSpecializedHeaders();
                        }
                    }
                });

        // Activity type buttons
        btnFood = root.findViewById(R.id.btn_type_food);
        btnWalk = root.findViewById(R.id.btn_type_walk);
        btnMedicine = root.findViewById(R.id.btn_type_medicine);
        btnNotes = root.findViewById(R.id.btn_type_notes);
        tvFoodLabel = root.findViewById(R.id.tv_food_label);
        tvWalkLabel = root.findViewById(R.id.tv_walk_label);
        tvMedLabel = root.findViewById(R.id.tv_med_label);
        tvNotesLabel = root.findViewById(R.id.tv_notes_label);

        btnFood.setOnClickListener(v -> selectType("Food"));
        btnWalk.setOnClickListener(v -> selectType("Walk"));
        btnMedicine.setOnClickListener(v -> selectType("Medicine"));
        btnNotes.setOnClickListener(v -> selectType("Notes"));

        initFoodForm(root);
        initWalkForm(root);
        initMedicineForm(root);
        initNotesForm(root);

        // Set initial selection
        selectType("Food");

        return root;
    }

    private void selectType(String type) {
        selectedType = type;
        
        // Update Card Backgrounds
        btnFood.setBackgroundResource(type.equals("Food") ? R.drawable.bg_btn_selected : R.drawable.bg_btn_unselected);
        btnWalk.setBackgroundResource(type.equals("Walk") ? R.drawable.bg_btn_selected : R.drawable.bg_btn_unselected);
        btnMedicine.setBackgroundResource(type.equals("Medicine") ? R.drawable.bg_btn_selected : R.drawable.bg_btn_unselected);
        btnNotes.setBackgroundResource(type.equals("Notes") ? R.drawable.bg_btn_selected : R.drawable.bg_btn_unselected);

        // Update Text Colors and Style
        int blue = getResources().getColor(R.color.color_primary_blue);
        int dark = getResources().getColor(R.color.text_primary);
        
        tvFoodLabel.setTextColor(type.equals("Food") ? blue : dark);
        tvFoodLabel.setTypeface(null, type.equals("Food") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        
        tvWalkLabel.setTextColor(type.equals("Walk") ? blue : dark);
        tvWalkLabel.setTypeface(null, type.equals("Walk") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        
        tvMedLabel.setTextColor(type.equals("Medicine") ? blue : dark);
        tvMedLabel.setTypeface(null, type.equals("Medicine") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        
        tvNotesLabel.setTextColor(type.equals("Notes") ? blue : dark);
        tvNotesLabel.setTypeface(null, type.equals("Notes") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);

        // UI Switching and Header Update
        if (type.equals("Food")) {
            llDefaultHeader.setVisibility(View.VISIBLE);
            containerFoodLog.setVisibility(View.VISIBLE);
            containerSpecializedLog.setVisibility(View.GONE);
            tvTitle.setText("What happened?");
            tvSubtitle.setText(String.format("Let's record %s's latest activity.", petName));
        } else {
            llDefaultHeader.setVisibility(View.GONE);
            containerFoodLog.setVisibility(View.GONE);
            containerSpecializedLog.setVisibility(View.VISIBLE);
            layoutLogWalk.setVisibility(type.equals("Walk") ? View.VISIBLE : View.GONE);
            layoutLogMedicine.setVisibility(type.equals("Medicine") ? View.VISIBLE : View.GONE);
            layoutLogNotes.setVisibility(type.equals("Notes") ? View.VISIBLE : View.GONE);
        }
    }


    private void updateSpecializedHeaders() {
        // Update header in specialized layouts if needed
    }

    private void initFoodForm(View root) {
        tvMealDry = root.findViewById(R.id.tv_meal_dry);
        tvMealWet = root.findViewById(R.id.tv_meal_wet);
        tvMealTreat = root.findViewById(R.id.tv_meal_treat);

        View.OnClickListener mealListener = v -> {
            tvMealDry.setBackgroundResource(R.drawable.bg_toggle_unselected);
            tvMealWet.setBackgroundResource(R.drawable.bg_toggle_unselected);
            tvMealTreat.setBackgroundResource(R.drawable.bg_toggle_unselected);
            tvMealDry.setTextColor(getResources().getColor(R.color.black));
            tvMealWet.setTextColor(getResources().getColor(R.color.black));
            tvMealTreat.setTextColor(getResources().getColor(R.color.black));

            v.setBackgroundResource(R.drawable.bg_toggle_selected);
            ((TextView) v).setTextColor(getResources().getColor(R.color.white));
            selectedMealType = ((TextView) v).getText().toString();
        };

        if (tvMealDry != null) {
            tvMealDry.setOnClickListener(mealListener);
            tvMealWet.setOnClickListener(mealListener);
            tvMealTreat.setOnClickListener(mealListener);
        }

        // Portion SeekBar
        SeekBar sbPortion = root.findViewById(R.id.sb_portion);
        tvPortionValue = root.findViewById(R.id.tv_portion_value);
        if (sbPortion != null) {
            sbPortion.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    portionSize = 0.5 + (progress * 0.5);
                    tvPortionValue.setText(portionSize + " cups");
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        // Time picker
        View llTime = root.findViewById(R.id.ll_time_input);
        if (llTime != null) {
            llTime.setOnClickListener(v -> {
                Calendar cal = Calendar.getInstance();
                new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                    cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    cal.set(Calendar.MINUTE, minute);
                    selectedTime = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cal.getTime());
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show();
            });
        }

        etDetails = root.findViewById(R.id.et_details);
        Button btnSubmit = root.findViewById(R.id.btn_submit);
        if (btnSubmit != null) btnSubmit.setOnClickListener(v -> {
            btnSubmit.setEnabled(false);
            btnSubmit.setText("Saving...");
            submitLog(btnSubmit);
        });
    }

    private void initWalkForm(View root) {
        SeekBar sbDuration = root.findViewById(R.id.sb_walk_duration);
        TextView tvDuration = root.findViewById(R.id.tv_duration_value);
        if (sbDuration != null && tvDuration != null) {
            sbDuration.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    int mins = 5 + progress;
                    tvDuration.setText(String.valueOf(mins));
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }
        
        // Cycle Conditions
        View cardConditions = root.findViewById(R.id.card_conditions);
        TextView tvWeather = root.findViewById(R.id.tv_weather_text);
        if (cardConditions != null && tvWeather != null) {
            final String[] conditions = {"Sunny", "Cloudy", "Rainy", "Snowy"};
            final int[] condIndex = {0};
            cardConditions.setOnClickListener(v -> {
                condIndex[0] = (condIndex[0] + 1) % conditions.length;
                tvWeather.setText(conditions[condIndex[0]]);
            });
        }

        // Cycle Intensity
        View cardIntensity = root.findViewById(R.id.card_intensity);
        TextView tvIntensity = root.findViewById(R.id.tv_intensity_text);
        if (cardIntensity != null && tvIntensity != null) {
            final String[] intensities = {"Active Play", "Leisurely Stroll", "Brisk Walk", "Run"};
            final int[] intIndex = {0};
            cardIntensity.setOnClickListener(v -> {
                intIndex[0] = (intIndex[0] + 1) % intensities.length;
                tvIntensity.setText(intensities[intIndex[0]]);
            });
        }

        Button btnComplete = root.findViewById(R.id.btn_complete_walk);
        if (btnComplete != null) btnComplete.setOnClickListener(v -> {
            btnComplete.setEnabled(false);
            btnComplete.setText("Saving...");
            String mins = tvDuration != null ? tvDuration.getText().toString() : "0";
            String cond = tvWeather != null ? tvWeather.getText().toString() : "Sunny";
            String intens = tvIntensity != null ? tvIntensity.getText().toString() : "Active Play";
            String details = mins + " minute walk • " + intens + " • " + cond;
            saveSpecializedLog("Walk", mins + " MINS", details, btnComplete, "Complete Walk Log");
        });
    }

    private void initMedicineForm(View root) {
        EditText etMedName = root.findViewById(R.id.et_search_medicine);
        EditText etDosage = root.findViewById(R.id.et_dosage);
        
        // Chips
        TextView chipApoquel = root.findViewById(R.id.chip_apoquel);
        TextView chipBravecto = root.findViewById(R.id.chip_bravecto);
        TextView chipNexgard = root.findViewById(R.id.chip_nexgard);
        android.view.View.OnClickListener chipListener = v -> {
            if (etMedName != null) etMedName.setText(((TextView) v).getText().toString());
        };
        if (chipApoquel != null) chipApoquel.setOnClickListener(chipListener);
        if (chipBravecto != null) chipBravecto.setOnClickListener(chipListener);
        if (chipNexgard != null) chipNexgard.setOnClickListener(chipListener);

        // Frequency Spinner
        android.widget.Spinner spinnerFreq = root.findViewById(R.id.spinner_frequency);
        if (spinnerFreq != null && getContext() != null) {
            String[] freqs = {"Once daily", "Twice daily", "As needed", "Weekly"};
            android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, freqs);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerFreq.setAdapter(adapter);
        }

        // Date Picker
        View llDate = root.findViewById(R.id.ll_date_picker);
        TextView tvDate = root.findViewById(R.id.tv_med_date);
        if (llDate != null && tvDate != null) {
            tvDate.setText(new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date()));
            llDate.setOnClickListener(v -> {
                Calendar cal = Calendar.getInstance();
                new android.app.DatePickerDialog(getContext(), (view, year, month, dayOfMonth) -> {
                    cal.set(year, month, dayOfMonth);
                    tvDate.setText(new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(cal.getTime()));
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
            });
        }

        // Time Picker
        View llTime = root.findViewById(R.id.ll_time_picker);
        TextView tvTime = root.findViewById(R.id.tv_med_time);
        if (llTime != null && tvTime != null) {
            tvTime.setText(new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()));
            llTime.setOnClickListener(v -> {
                Calendar cal = Calendar.getInstance();
                new TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
                    cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    cal.set(Calendar.MINUTE, minute);
                    tvTime.setText(new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cal.getTime()));
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show();
            });
        }
        
        EditText etNotes = root.findViewById(R.id.et_med_notes);

        Button btnSaveMed = root.findViewById(R.id.btn_save_med_log);
        if (btnSaveMed != null) btnSaveMed.setOnClickListener(v -> {
            btnSaveMed.setEnabled(false);
            btnSaveMed.setText("Saving...");
            String med = etMedName != null ? etMedName.getText().toString().trim() : "";
            if (med.isEmpty()) med = "Medicine";
            
            String dosage = etDosage != null && !etDosage.getText().toString().isEmpty() ? etDosage.getText().toString() : "";
            String date = tvDate != null ? tvDate.getText().toString() : "";
            String time = tvTime != null ? tvTime.getText().toString() : "";
            String freq = spinnerFreq != null ? spinnerFreq.getSelectedItem().toString() : "";
            String notes = etNotes != null ? etNotes.getText().toString().trim() : "";
            
            String details = med;
            if (!dosage.isEmpty()) details += " (" + dosage + ")";
            if (!freq.isEmpty()) details += " • " + freq;
            if (!notes.isEmpty()) details += "\nNote: " + notes;
            
            saveSpecializedLog("Medicine", "ADMINISTERED", details, btnSaveMed, "Save Medicine Log");
        });
    }

    private void initNotesForm(View root) {
        View btnHappy = root.findViewById(R.id.btn_mood_happy);
        View btnSleepy = root.findViewById(R.id.btn_mood_sleepy);
        View btnGrumpy = root.findViewById(R.id.btn_mood_grumpy);
        View btnEnergetic = root.findViewById(R.id.btn_mood_energetic);

        // Icon ImageViews
        android.widget.ImageView imgHappy = root.findViewById(R.id.img_happy);
        android.widget.ImageView imgSleepy = root.findViewById(R.id.img_sleepy);
        android.widget.ImageView imgGrumpy = root.findViewById(R.id.img_grumpy);
        android.widget.ImageView imgEnergetic = root.findViewById(R.id.img_energetic);

        // Text labels
        TextView tvHappy = root.findViewById(R.id.tv_happy);
        TextView tvSleepy = root.findViewById(R.id.tv_sleepy);
        TextView tvGrumpy = root.findViewById(R.id.tv_grumpy);
        TextView tvEnergetic = root.findViewById(R.id.tv_energetic);

        View[] moodBtns = {btnHappy, btnSleepy, btnGrumpy, btnEnergetic};
        android.widget.ImageView[] moodIcons = {imgHappy, imgSleepy, imgGrumpy, imgEnergetic};
        TextView[] moodTexts = {tvHappy, tvSleepy, tvGrumpy, tvEnergetic};
        String[] moodNames = {"Happy", "Sleepy", "Grumpy", "Energetic"};

        int blueColor = getResources().getColor(R.color.color_primary_blue);
        int grayColor = getResources().getColor(R.color.text_secondary);

        for (int i = 0; i < moodBtns.length; i++) {
            final int idx = i;
            if (moodBtns[i] != null) {
                moodBtns[i].setOnClickListener(v -> {
                    selectedMood = moodNames[idx];
                    for (int j = 0; j < moodBtns.length; j++) {
                        if (j == idx) {
                            moodBtns[j].setBackgroundResource(R.drawable.bg_btn_selected);
                            if (moodIcons[j] != null) moodIcons[j].setColorFilter(blueColor);
                            if (moodTexts[j] != null) {
                                moodTexts[j].setTextColor(blueColor);
                                moodTexts[j].setTypeface(null, android.graphics.Typeface.BOLD);
                            }
                        } else {
                            moodBtns[j].setBackgroundResource(R.drawable.bg_btn_unselected);
                            if (moodIcons[j] != null) moodIcons[j].setColorFilter(grayColor);
                            if (moodTexts[j] != null) {
                                moodTexts[j].setTextColor(grayColor);
                                moodTexts[j].setTypeface(null, android.graphics.Typeface.NORMAL);
                            }
                        }
                    }
                });
            }
        }
        // Tag Activity chips
        com.google.android.material.chip.ChipGroup chipGroup = root.findViewById(R.id.chip_group_tags);
        final String[] selectedTag = {""};
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
                if (!checkedIds.isEmpty()) {
                    com.google.android.material.chip.Chip chip = group.findViewById(checkedIds.get(0));
                    if (chip != null) selectedTag[0] = chip.getText().toString();
                } else {
                    selectedTag[0] = "";
                }
            });
        }

        EditText etNotes = root.findViewById(R.id.et_general_notes);
        Button btnSave = root.findViewById(R.id.btn_save_notes);
        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                btnSave.setEnabled(false);
                btnSave.setText("Saving...");
                String note = etNotes.getText().toString().trim();
                String details = note.isEmpty() ? "Pet is feeling " + selectedMood : note;
                if (!selectedTag[0].isEmpty()) {
                    details = details + " • " + selectedTag[0];
                }
                saveSpecializedLog("Notes", selectedMood.toUpperCase(), details, btnSave, "Save Notes");
            });
        }
    }

    private void saveSpecializedLog(String type, String tag, String details, Button saveButton, String originalText) {
        Map<String, Object> log = new HashMap<>();
        log.put("type", type);
        log.put("tag", tag);
        log.put("additionalDetails", details);
        String petId = getContext().getSharedPreferences("CarePaws", 0).getString("currentPetId", "");
        log.put("petId", petId);
        log.put("timestamp", System.currentTimeMillis());
        log.put("time", new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()));

        db.collection("users").document(uid).collection("logs")
                .add(log)
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Error saving to cloud: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });

        // Optimistic UI update: instantly show success without waiting for network confirmation
        if (saveButton != null) {
            saveButton.setText("Saved ✓");
            saveButton.postDelayed(() -> {
                saveButton.setEnabled(true);
                saveButton.setText(originalText);
            }, 1000);
        }
    }

    private void submitLog(Button submitButton) {
        String details = etDetails.getText().toString().trim();

        Map<String, Object> log = new HashMap<>();
        log.put("type", selectedType);
        log.put("mealType", selectedMealType);
        log.put("portionSize", portionSize + " cups");
        log.put("time", selectedTime);
        String petId = getContext().getSharedPreferences("CarePaws", 0).getString("currentPetId", "");
        log.put("petId", petId);
        log.put("additionalDetails", details.isEmpty() ? selectedType + " logged" : details);
        log.put("timestamp", System.currentTimeMillis());

        // Set tag based on type
        String tag = "";
        switch (selectedType) {
            case "Food": tag = "NUTRITION MET"; break;
            case "Walk": tag = portionSize + " MINS"; break;
            case "Medicine": tag = "ADMINISTERED"; break;
            case "Notes": tag = "NOTE ADDED"; break;
        }
        log.put("tag", tag);

        db.collection("users").document(uid).collection("logs")
                .add(log)
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Error saving to cloud: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });

        // Optimistic UI update
        if (etDetails != null) etDetails.setText("");
        if (submitButton != null) {
            submitButton.setText("Saved ✓");
            submitButton.postDelayed(() -> {
                submitButton.setEnabled(true);
                submitButton.setText("Submit Log");
            }, 1000);
        }
    }
}
