package com.example.carepaws.ui.home;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.carepaws.R;
import com.example.carepaws.model.LogEntry;
import java.util.List;

public class TimelineAdapter extends RecyclerView.Adapter<TimelineAdapter.TimelineViewHolder> {

    private List<LogEntry> logList;
    private boolean isExpanded = false;
    private OnLogDeleteListener deleteListener;

    public interface OnLogDeleteListener {
        void onDeleteClick(LogEntry log);
    }

    public TimelineAdapter(List<LogEntry> logList, OnLogDeleteListener deleteListener) {
        this.logList = logList;
        this.deleteListener = deleteListener;
    }

    public void setExpanded(boolean expanded) {
        isExpanded = expanded;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TimelineViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_health_timeline, parent, false);
        return new TimelineViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TimelineViewHolder holder, int position) {
        LogEntry log = logList.get(position);

        // Hide top line for first item, bottom line for last item
        holder.vLineTop.setVisibility(position == 0 ? View.INVISIBLE : View.VISIBLE);
        holder.vLineBottom.setVisibility(position == getItemCount() - 1 ? View.INVISIBLE : View.VISIBLE);

        holder.tvLogTitle.setText(log.getType());
        holder.tvLogTime.setText(log.getTime());
        holder.tvLogDesc.setText(log.getAdditionalDetails());
        holder.tvLogStatus.setText(log.getTag());

        // Set icon & colors based on type
        int iconRes = R.drawable.ic_home; // fallback
        int bgRes = R.drawable.bg_timeline_icon_green;
        int statusColorId = R.color.color_primary_blue;
        
        switch (log.getType()) {
            case "Walk":
                bgRes = R.drawable.bg_timeline_icon_green;
                statusColorId = R.color.color_primary_blue;
                break;
            case "Food":
                bgRes = R.drawable.bg_timeline_icon_blue;
                statusColorId = R.color.status_green;
                holder.tvLogStatus.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_add, 0, 0, 0);
                break;
            case "Medicine":
                bgRes = R.drawable.bg_timeline_icon_orange;
                statusColorId = R.color.status_red_orange;
                break;
            case "Notes":
                bgRes = R.drawable.bg_timeline_icon_blue;
                statusColorId = R.color.color_primary_blue;
                break;
        }

        holder.flIcon.setBackgroundResource(bgRes);
        holder.tvLogStatus.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), statusColorId));

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteClick(log);
            }
        });
        
        holder.itemView.setOnLongClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteClick(log);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        if (logList == null) return 0;
        if (isExpanded) return logList.size();
        return Math.min(2, logList.size());
    }

    static class TimelineViewHolder extends RecyclerView.ViewHolder {
        View vLineTop, vLineBottom;
        FrameLayout flIcon;
        ImageView imgTypeIcon, btnDelete;
        TextView tvLogTitle, tvLogTime, tvLogDesc, tvLogStatus;

        public TimelineViewHolder(@NonNull View itemView) {
            super(itemView);
            vLineTop = itemView.findViewById(R.id.v_line_top);
            vLineBottom = itemView.findViewById(R.id.v_line_bottom);
            flIcon = itemView.findViewById(R.id.fl_icon);
            imgTypeIcon = itemView.findViewById(R.id.img_type_icon);
            btnDelete = itemView.findViewById(R.id.btn_delete_log);
            tvLogTitle = itemView.findViewById(R.id.tv_log_title);
            tvLogTime = itemView.findViewById(R.id.tv_log_time);
            tvLogDesc = itemView.findViewById(R.id.tv_log_desc);
            tvLogStatus = itemView.findViewById(R.id.tv_log_status);
        }
    }
}
