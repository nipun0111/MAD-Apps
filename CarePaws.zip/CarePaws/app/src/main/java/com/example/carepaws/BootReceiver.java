package com.example.carepaws;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.carepaws.model.Reminder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                FirebaseFirestore.getInstance().collection("users").document(user.getUid())
                        .collection("reminders")
                        .whereEqualTo("notifyEnabled", true)
                        .get()
                        .addOnSuccessListener(queryDocumentSnapshots -> {
                            long currentTime = System.currentTimeMillis();
                            for (DocumentSnapshot doc : queryDocumentSnapshots) {
                                Reminder r = doc.toObject(Reminder.class);
                                if (r != null && r.getTriggerTimestamp() > currentTime) {
                                    r.setId(doc.getId());
                                    scheduleAlarm(context, r);
                                }
                            }
                        });
            }
        }
    }

    private void scheduleAlarm(Context ctx, Reminder r) {
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        intent.putExtra("title", r.getTitle());
        intent.putExtra("type", r.getType());

        int requestCode = r.getId() != null ? r.getId().hashCode() : 0;
        PendingIntent pi = PendingIntent.getBroadcast(ctx, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.getTriggerTimestamp(), pi);
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.getTriggerTimestamp(), pi);
            }
        }
    }
}
