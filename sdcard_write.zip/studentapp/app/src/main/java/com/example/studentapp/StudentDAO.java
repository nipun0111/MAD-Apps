package com.example.studentapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class StudentDAO {

    DBHelper dbHelper;

    public StudentDAO(Context context) {
        dbHelper = new DBHelper(context);
    }

    public boolean insertData(String name, String roll, String marks) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("name", name);
        cv.put("roll", roll);
        cv.put("marks", marks);

        long result = db.insert("students", null, cv);
        return result != -1;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        return db.rawQuery("SELECT * FROM students", null);
    }
}