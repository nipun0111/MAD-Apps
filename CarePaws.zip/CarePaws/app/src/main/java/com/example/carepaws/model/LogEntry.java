package com.example.carepaws.model;

public class LogEntry {
    private String id;
    private String type; // Walk, Food, Medicine, Notes
    private String mealType; // Dry Kibble, Wet Food, Treat
    private String portionSize;
    private String time;
    private String additionalDetails;
    private String tag; // e.g. "NUTRITION MET", "URGENT: NEXT DUE AUG 15"
    private String petId;
    private long timestamp;

    public LogEntry() {
        // Default constructor required for calls to DataSnapshot.getValue(LogEntry.class)
    }

    public LogEntry(String type, String mealType, String portionSize, String time, String additionalDetails, String tag, String petId, long timestamp) {
        this.type = type;
        this.mealType = mealType;
        this.portionSize = portionSize;
        this.time = time;
        this.additionalDetails = additionalDetails;
        this.tag = tag;
        this.petId = petId;
        this.timestamp = timestamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getPortionSize() {
        return portionSize;
    }

    public void setPortionSize(String portionSize) {
        this.portionSize = portionSize;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAdditionalDetails() {
        return additionalDetails;
    }

    public void setAdditionalDetails(String additionalDetails) {
        this.additionalDetails = additionalDetails;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
