package com.example.contact;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ExtendedFloatingActionButton fabAdd;
    EditText etSearch;
    DBHelper dbHelper;
    ContactAdapter adapter;
    List<Contact> contactList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        fabAdd = findViewById(R.id.fabAdd);
        etSearch = findViewById(R.id.etSearch);
        dbHelper = new DBHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Insert dummy data if DB is empty
        insertDummyDataIfNeeded();

        loadContacts();

        fabAdd.setOnClickListener(v -> showAddContactDialog());

        // Search Bar Logic
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void insertDummyDataIfNeeded() {
        if (dbHelper.getContactsCount() == 0) {
            dbHelper.addContact("Aarav Sharma", "+91 9876543210");
            dbHelper.addContact("Bhavya Singh", "+91 8765432109");
            dbHelper.addContact("Chirag Gupta", "+91 7654321098");
            dbHelper.addContact("David John", "+91 6543210987");
            dbHelper.addContact("Esha Verma", "+91 5432109876");
            dbHelper.addContact("Faisal Khan", "+91 4321098765");
            dbHelper.addContact("Gaurav Patel", "+91 3210987654");
            dbHelper.addContact("Hari Om", "+91 2109876543");
            dbHelper.addContact("Ishan Ali", "+91 1098765432");
            dbHelper.addContact("Jiya Das", "+91 9988776655");
            dbHelper.addContact("Karan Kapoor", "+91 8877665544");
            dbHelper.addContact("Zara Shaikh", "+91 7766554433");
        }
    }

    private void filter(String text) {
        List<Contact> filteredList = new ArrayList<>();
        for (Contact item : contactList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase()) ||
                    item.getPhone().contains(text)) {
                filteredList.add(item);
            }
        }
        adapter.filterList(filteredList);
    }

    private void loadContacts() {
        contactList.clear();
        Cursor cursor = dbHelper.getAllContactsSorted();

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(0);
                String name = cursor.getString(1);
                String phone = cursor.getString(2);

                contactList.add(new Contact(id, name, phone));
            } while (cursor.moveToNext());
        }

        adapter = new ContactAdapter(this, contactList);
        recyclerView.setAdapter(adapter);
    }

    private void showAddContactDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Contact");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 30, 60, 30);

        final EditText inputName = new EditText(this);
        inputName.setHint("Name");
        layout.addView(inputName);

        final EditText inputPhone = new EditText(this);
        inputPhone.setHint("Phone Number");
        inputPhone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        inputPhone.setPadding(0, 30, 0, 0);
        layout.addView(inputPhone);

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String name = inputName.getText().toString().trim();
            String phone = inputPhone.getText().toString().trim();

            if (!name.isEmpty() && !phone.isEmpty()) {
                dbHelper.addContact(name, phone);
                loadContacts();
                etSearch.setText(""); // Reset search on new contact
            } else {
                Toast.makeText(this, "Please enter both details", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}