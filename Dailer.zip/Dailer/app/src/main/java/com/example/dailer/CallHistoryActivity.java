package com.example.dailer;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class CallHistoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_history);

        HistoryDatabaseHelper db = new HistoryDatabaseHelper(this);
        ListView lvHistory = findViewById(R.id.lvHistory);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, db.getHistory());
        lvHistory.setAdapter(adapter);
    }
}