package com.example.carepaws.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.navigation.Navigation;
import com.example.carepaws.PetSetupActivity;
import com.example.carepaws.R;
import com.example.carepaws.model.LogEntry;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import com.bumptech.glide.Glide;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

public class HomeFragment extends Fragment {

    private FirebaseFirestore db;
    private String uid;
    private TextView tvPetName, tvPetBreed, tvPetAge, tvPetWeight, tvGoalsSummary, tvPercentage, tvViewAllTimeline;
    private ProgressBar pbGoalsOuter;
    private View petProfileContainer, emptyStateContainer, cardGoalsContainer;
    private RecyclerView rvTimeline;
    private TimelineAdapter adapter;
    private List<LogEntry> logList = new ArrayList<>();
    private List<DocumentSnapshot> petList = new ArrayList<>();
    private int currentPetIndex = 0;
    private boolean isTimelineExpanded = false;
    private int walkTarget = 3;
    private int foodTarget = 2;

    private final ActivityResultLauncher<String> mGetContent = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null && getContext() != null && !petList.isEmpty()) {
                    String petId = petList.get(currentPetIndex).getId();
                    saveImageToLocal(uri, petId);
                    loadImageFromLocal(petId);
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        db = FirebaseFirestore.getInstance();
        uid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : "";

        tvPetName = root.findViewById(R.id.tv_pet_name);
        tvPetBreed = root.findViewById(R.id.tv_pet_breed);
        tvPetAge = root.findViewById(R.id.tv_pet_age);
        tvPetWeight = root.findViewById(R.id.tv_pet_weight);
        tvGoalsSummary = root.findViewById(R.id.tv_goals_summary);
        tvPercentage = root.findViewById(R.id.tv_goals_percentage);
        tvViewAllTimeline = root.findViewById(R.id.tv_view_all_timeline);
        pbGoalsOuter = root.findViewById(R.id.pb_goals_outer);
        rvTimeline = root.findViewById(R.id.rv_health_timeline);
        petProfileContainer = root.findViewById(R.id.pet_profile_container);
        emptyStateContainer = root.findViewById(R.id.empty_state_container);
        cardGoalsContainer = root.findViewById(R.id.card_goals_container);

        root.findViewById(R.id.btn_add_pet).setOnClickListener(v -> startPetSetup());
        root.findViewById(R.id.btn_setup_first_pet).setOnClickListener(v -> startPetSetup());
        root.findViewById(R.id.btn_switch_pet).setOnClickListener(v -> switchPet());

        tvViewAllTimeline.setOnClickListener(v -> {
            isTimelineExpanded = !isTimelineExpanded;
            tvViewAllTimeline.setText(isTimelineExpanded ? "View Less" : "View All");
            adapter.setExpanded(isTimelineExpanded);
        });

        cardGoalsContainer.setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.navigation_goals);
        });

        de.hdodenhof.circleimageview.CircleImageView imgPet = root.findViewById(R.id.img_pet);
        if (imgPet != null) {
            imgPet.setOnClickListener(v -> mGetContent.launch("image/*"));
        }

        rvTimeline.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new TimelineAdapter(logList, log -> {
            new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Delete Log")
                .setMessage("Are you sure you want to delete this log?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.collection("users").document(uid).collection("logs").document(log.getId()).delete();
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
        rvTimeline.setAdapter(adapter);

        loadPetProfiles();

        return root;
    }

    private void startPetSetup() {
        startActivity(new Intent(getContext(), PetSetupActivity.class));
    }

    private void switchPet() {
        if (petList.size() > 1) {
            currentPetIndex = (currentPetIndex + 1) % petList.size();
            displayCurrentPet();
        }
    }

    private void loadPetProfiles() {
        if (uid == null) return;
        
        db.collection("users").document(uid).collection("pets")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    if (isAdded()) {
                        petList.clear();
                        if (!querySnapshot.isEmpty()) {
                            petList.addAll(querySnapshot.getDocuments());
                            petProfileContainer.setVisibility(View.VISIBLE);
                            emptyStateContainer.setVisibility(View.GONE);
                            displayCurrentPet();
                        } else {
                            petProfileContainer.setVisibility(View.GONE);
                            emptyStateContainer.setVisibility(View.VISIBLE);
                        }
                    }
                })
                .addOnFailureListener(e -> {
                    if (isAdded()) {
                        android.util.Log.e("HomeFragment", "Error loading pets", e);
                        petProfileContainer.setVisibility(View.GONE);
                        emptyStateContainer.setVisibility(View.VISIBLE);
                        // Show error message to user
                        if (getContext() != null) {
                            android.widget.Toast.makeText(getContext(), 
                                "Database Error: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void displayCurrentPet() {
        if (petList.isEmpty()) return;
        DocumentSnapshot doc = petList.get(currentPetIndex);
        String name = doc.getString("name");
        String breed = doc.getString("breed");
        Long age = doc.getLong("age");
        Long weight = doc.getLong("weight");
        String petId = doc.getId();

        // Save selected petId to preferences for AddLogFragment
        if (getContext() != null) {
            getContext().getSharedPreferences("CarePaws", 0).edit().putString("currentPetId", petId).apply();
        }

        if (name != null) {
            tvPetName.setText(name);
            if (tvGoalsSummary != null) {
                tvGoalsSummary.setText(name + " is all set for the day!");
            }
        }
        if (breed != null) tvPetBreed.setText(breed);
        if (age != null) tvPetAge.setText(age + " years");
        if (weight != null) tvPetWeight.setText(weight + " kg");

        loadImageFromLocal(petId);

        Long wt = doc.getLong("walkTarget");
        Long ft = doc.getLong("foodTarget");
        walkTarget = (wt != null) ? wt.intValue() : 3;
        foodTarget = (ft != null) ? ft.intValue() : 2;

        loadLogsForPet(petId);
        updateDailyGoals(petId);
    }

    private void updateDailyGoals(String petId) {
        Calendar startOfDay = Calendar.getInstance();
        startOfDay.set(Calendar.HOUR_OF_DAY, 0);
        startOfDay.set(Calendar.MINUTE, 0);
        startOfDay.set(Calendar.SECOND, 0);

        db.collection("users").document(uid).collection("logs")
                .whereEqualTo("petId", petId)
                .whereGreaterThanOrEqualTo("timestamp", startOfDay.getTimeInMillis())
                .get()
                .addOnSuccessListener(qs -> {
                    int walkCount = 0;
                    int foodCount = 0;
                    for (DocumentSnapshot doc : qs.getDocuments()) {
                        String type = doc.getString("type");
                        if ("Walk".equals(type)) walkCount++;
                        else if ("Food".equals(type)) foodCount++;
                    }

                    // Dynamic targets from pet profile
                    int totalGoals = walkTarget + foodTarget;
                    int completed = Math.min(walkCount, walkTarget) + Math.min(foodCount, foodTarget);
                    int percentage = (int) (((float) completed / totalGoals) * 100);

                    if (tvPercentage != null) tvPercentage.setText(percentage + "%");
                    if (pbGoalsOuter != null) pbGoalsOuter.setProgress(percentage);
                    if (tvGoalsSummary != null) {
                        if (percentage >= 100) tvGoalsSummary.setText("All daily goals met! Great job!");
                        else tvGoalsSummary.setText("Keep going! You're " + percentage + "% there.");
                    }
                });
    }

    private void loadLogsForPet(String petId) {
        db.collection("users").document(uid).collection("logs")
                .whereEqualTo("petId", petId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(50)
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null) return;
                    logList.clear();
                    for (DocumentSnapshot doc : value.getDocuments()) {
                        LogEntry log = doc.toObject(LogEntry.class);
                        if (log != null) {
                            log.setId(doc.getId());
                            logList.add(log);
                        }
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void saveImageToLocal(android.net.Uri uri, String petId) {
        try {
            java.io.InputStream is = getContext().getContentResolver().openInputStream(uri);
            java.io.File file = new java.io.File(getContext().getFilesDir(), petId + "_avatar.jpg");
            java.io.OutputStream os = new java.io.FileOutputStream(file);
            byte[] buf = new byte[1024];
            int len;
            while ((len = is.read(buf)) > 0) {
                os.write(buf, 0, len);
            }
            is.close();
            os.close();
            db.collection("users").document(uid).collection("pets").document(petId).update("hasAvatar", true);
        } catch (Exception e) {
            e.printStackTrace();
            android.widget.Toast.makeText(getContext(), "Failed to save image", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void loadImageFromLocal(String petId) {
        if (getView() == null) return;
        de.hdodenhof.circleimageview.CircleImageView imgPet = getView().findViewById(R.id.img_pet);
        if (imgPet == null) return;
        
        java.io.File file = new java.io.File(getContext().getFilesDir(), petId + "_avatar.jpg");
        if (file.exists()) {
            Glide.with(this).load(file).into(imgPet);
        } else {
            imgPet.setImageResource(R.drawable.ic_home);
        }
    }

}
