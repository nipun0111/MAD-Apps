package com.example.carepaws.ui.reminders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.carepaws.R;
import com.example.carepaws.model.Reminder;
import java.util.List;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ReminderViewHolder> {

    public interface OnToggleListener {
        void onToggle(Reminder reminder, boolean enabled);
    }

    public interface OnReminderDeleteListener {
        void onDelete(Reminder reminder);
    }

    private List<Reminder> reminders;
    private OnToggleListener listener;
    private OnReminderDeleteListener deleteListener;

    public ReminderAdapter(List<Reminder> reminders, OnToggleListener listener, OnReminderDeleteListener deleteListener) {
        this.reminders = reminders;
        this.listener = listener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ReminderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reminder, parent, false);
        return new ReminderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReminderViewHolder holder, int position) {
        Reminder r = reminders.get(position);
        holder.tvTitle.setText(r.getTitle());
        holder.tvDateTime.setText(r.getDateTime());
        holder.switchNotify.setChecked(r.isNotifyEnabled());

        // Set icon and background based on type
        int iconRes = R.drawable.ic_medical;
        int bgRes = R.drawable.bg_timeline_icon_orange;

        if (r.getType() != null) {
            switch (r.getType()) {
                case "Walk":
                    iconRes = R.drawable.ic_walk;
                    bgRes = R.drawable.bg_timeline_icon_green;
                    break;
                case "Vet":
                    iconRes = R.drawable.ic_vet;
                    bgRes = R.drawable.bg_timeline_icon_blue;
                    break;
                case "Grooming":
                    iconRes = R.drawable.ic_scissors;
                    bgRes = R.drawable.bg_timeline_icon_blue;
                    break;
                case "Medicine":
                default:
                    iconRes = R.drawable.ic_medical;
                    bgRes = R.drawable.bg_timeline_icon_orange;
                    break;
            }
        }

        holder.imgIcon.setImageResource(iconRes);
        holder.flIcon.setBackgroundResource(bgRes);

        holder.switchNotify.setOnCheckedChangeListener(null);
        holder.switchNotify.setChecked(r.isNotifyEnabled());
        holder.switchNotify.setOnCheckedChangeListener((btn, isChecked) -> {
            if (listener != null) {
                listener.onToggle(r, isChecked);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDelete(r);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return reminders == null ? 0 : reminders.size();
    }

    static class ReminderViewHolder extends RecyclerView.ViewHolder {
        FrameLayout flIcon;
        ImageView imgIcon;
        TextView tvTitle, tvDateTime;
        SwitchCompat switchNotify;

        public ReminderViewHolder(@NonNull View itemView) {
            super(itemView);
            flIcon = itemView.findViewById(R.id.fl_icon);
            imgIcon = itemView.findViewById(R.id.img_icon);
            tvTitle = itemView.findViewById(R.id.tv_reminder_title);
            tvDateTime = itemView.findViewById(R.id.tv_reminder_datetime);
            switchNotify = itemView.findViewById(R.id.switch_notify);
        }
    }
}
